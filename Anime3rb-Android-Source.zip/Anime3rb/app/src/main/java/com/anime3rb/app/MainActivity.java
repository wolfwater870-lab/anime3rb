package com.anime3rb.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String HOME = "https://anime3rb.com/";
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,16,24));
        getWindow().setNavigationBarColor(Color.rgb(16,16,24));
        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.addJavascriptInterface(new DownloadBridge(this), "Anime3rbApp");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host != null && (host.equals("anime3rb.com") || host.endsWith(".anime3rb.com"))) return false;
                // Keep external video hosts inside the player; other external pages are opened by WebView too.
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && (url.startsWith(HOME) || url.contains("anime3rb.com/"))) injectBatchPicker();
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                enqueueDownload(url, contentDisposition, mimeType));
        if (state == null) web.loadUrl(HOME); else web.restoreState(state);
    }

    private void injectBatchPicker() {
        String js = "(function(){if(document.getElementById('a3rb-batch'))return;" +
          "const b=document.createElement('button');b.id='a3rb-batch';b.textContent='اختيار روابط التحميل';" +
          "b.style='position:fixed;z-index:2147483647;bottom:18px;left:14px;background:#7048e8;color:white;border:0;border-radius:24px;padding:13px 17px;font: bold 14px sans-serif;box-shadow:0 3px 14px #0008';" +
          "b.onclick=function(){let old=document.getElementById('a3rb-panel');if(old){old.remove();return;}" +
          "let links=[...document.querySelectorAll('a[href],video source[src],video[src]')].map(x=>({u:x.href||x.src,t:(x.innerText||x.getAttribute('download')||'ملف فيديو').trim()}));" +
          "links=links.filter(x=>/^https:\\/\\//i.test(x.u)&&/\\.(mp4|mkv|webm)(?:$|[?#])/i.test(x.u));" +
          "let p=document.createElement('div');p.id='a3rb-panel';p.dir='rtl';p.style='position:fixed;z-index:2147483647;bottom:75px;left:12px;width:min(88vw,380px);max-height:55vh;overflow:auto;background:#171722;color:white;padding:14px;border:1px solid #7660bd;border-radius:14px;font:14px sans-serif;box-shadow:0 4px 20px #000b';" +
          "let h=document.createElement('b');h.textContent='روابط الفيديو المباشرة المتاحة';p.appendChild(h);" +
          "if(!links.length){let m=document.createElement('p');m.textContent='لم يتم العثور على روابط فيديو مباشرة في هذه الصفحة. قد يكون المشغل داخل إطار خارجي أو يستخدم بث HLS.';p.appendChild(m)}" +
          "links.forEach((x,i)=>{let l=document.createElement('label');l.style='display:block;padding:9px 0;border-bottom:1px solid #444';let c=document.createElement('input');c.type='checkbox';c.value=i;c.style='margin-left:8px';l.appendChild(c);l.appendChild(document.createTextNode((i+1)+'. '+(x.t||'فيديو').slice(0,70)));p.appendChild(l)});" +
          "let d=document.createElement('button');d.textContent='تحميل المحدد';d.style='margin-top:12px;padding:10px 14px;background:#7048e8;color:white;border:0;border-radius:9px';" +
          "d.onclick=function(){let chosen=[...p.querySelectorAll('input:checked')].map(c=>links[+c.value]);chosen.forEach((x,i)=>setTimeout(()=>Anime3rbApp.download(x.u,x.t||('episode-'+(i+1))),i*250));p.remove()};p.appendChild(d);document.body.appendChild(p)};document.body.appendChild(b)})();";
        web.evaluateJavascript(js, null);
    }

    private void enqueueDownload(String url, String disposition, String mime) {
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme())) { toast("يُسمح بتنزيل روابط HTTPS فقط"); return; }
            DownloadManager.Request req = new DownloadManager.Request(uri);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setTitle(fileName(url, disposition));
            req.setDescription("Anime3rb – تنزيل الحلقة");
            req.setAllowedOverMetered(true);
            req.setAllowedOverRoaming(false);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Anime3rb/" + fileName(url, disposition));
            if (mime != null && !mime.isEmpty()) req.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            Object service = getSystemService(Context.DOWNLOAD_SERVICE);
            ((DownloadManager)service).enqueue(req);
            toast("تمت إضافة الحلقة إلى قائمة التنزيلات");
        } catch (Exception e) { toast("تعذر بدء التحميل من هذا الرابط"); }
    }

    private String fileName(String url, String disposition) {
        String name = "anime3rb-video.mp4";
        try {
            if (disposition != null && disposition.toLowerCase(Locale.ROOT).contains("filename=")) {
                name = disposition.substring(disposition.toLowerCase(Locale.ROOT).indexOf("filename=")+9).replace("\"", "").trim();
            } else {
                String path = new URL(url).getPath();
                int slash = path.lastIndexOf('/'); if (slash >= 0 && slash < path.length()-1) name = URLDecoder.decode(path.substring(slash+1), StandardCharsets.UTF_8.name());
            }
        } catch (Exception ignored) {}
        name = name.replaceAll("[^\\p{L}\\p{N}._ -]", "_");
        if (name.length() > 100) name = name.substring(0,100);
        if (!name.contains(".")) name += ".mp4";
        return name;
    }

    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    public class DownloadBridge {
        private final MainActivity activity;
        DownloadBridge(MainActivity a) { activity = a; }
        @JavascriptInterface public void download(String url, String title) {
            activity.runOnUiThread(() -> activity.enqueueDownload(url, null, "video/*"));
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }
    @Override protected void onDestroy() { if (web != null) { web.removeJavascriptInterface("Anime3rbApp"); web.destroy(); } super.onDestroy(); }
}
